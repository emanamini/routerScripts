#!/usr/bin/env bash
# install.sh
# Master entry point for the Arch Router Deployment.

# Strict Error Handling
set -euo pipefail

echo "========================================================"
echo "        ARCH LINUX ROUTER DEPLOYMENT SCRIPT           "
echo "========================================================"
echo ""

# Ensure the script always runs from the correct directory,
# even if the user calls it from a different path.
cd "$(dirname "$0")"

# We use 'source' (instead of standard execution) so that variables
# discovered in early modules are passed smoothly into later modules.

echo "[1/9] Validating System Architecture..."
source modules/01-system-check.sh
echo ""

echo "[2/9] Checking Required Packages..."
source modules/02-package-check.sh
echo ""

echo "[3/9] Detecting Administrative User..."
source modules/03-user-detection.sh
echo ""

echo "[4/9] Configuring Network Interfaces..."
source modules/04-network-detection.sh
echo ""

echo "[5/9] Backing up Existing Configurations..."
source modules/05-backup.sh
echo ""

echo "[6/9] Extracting and Installing Files..."
source modules/06-install-files.sh
echo ""

echo "[7/9] Setting up DLNA Media Environment..."
source modules/07-media-setup.sh
echo ""

echo "[8/9] Enabling Core System Services..."
source modules/08-enable-services.sh
echo ""

echo "[9/9] Optional: Configuring Caddy & Cloudflare SSL..."
if [ -f "modules/09-caddy-ssl.sh" ]; then
    source modules/09-caddy-ssl.sh
else
    echo "Skipping... (09-caddy-ssl.sh not found)"
fi
echo ""

echo "========================================================"
echo "                INSTALLATION COMPLETE!                "
echo "========================================================"
echo "Your Arch Linux machine is now configured as a router."
echo "Please reboot the system to apply all network settings"
echo "and allow the delayed-startup service to initialize."
echo "========================================================"
