#!/usr/bin/env bash
# 08-enable-services.sh
# Enforces executable permissions, applies kernel rules, and enables base systemd services.

# Strict Error Handling
set -euo pipefail

echo "Starting Service Activation..."

# 1. Guarantee Executable Permissions for all Router Scripts
echo "Enforcing executable permissions on /opt/router/Scripts/..."
if [[ -d "/opt/router/Scripts" ]]; then
  # Find all files in the directory and ensure they are executable
  find "/opt/router/Scripts" -type f -exec chmod +x {} \;
  echo "  - Executable permissions verified."
else
  echo "ERROR: /opt/router/Scripts/ directory not found." >&2
  exit 1
fi

# 2. Apply Kernel Parameters (IPv4 Forwarding, BBR, TCP optimizations)
echo "Applying sysctl network parameters..."
sysctl --system

# 3. Enable Base Systemd Services
# We strictly mimic the list provided, leaving secondary services to delayed-startup.service
BASE_SERVICES=(
  "cronie.service"
  "delayed-startup.service"
  "nftables.service"
  "sshd.service"
  "systemd-network-generator.service"
  "systemd-networkd-wait-online.service"
  "systemd-networkd.service"
  "systemd-timesyncd.service"
  "vnstat.service"
)

echo "Enabling core systemd services to start on boot..."

for service in "${BASE_SERVICES[@]}"; do
  echo "  - Enabling ${service}..."
  # We use 'systemctl enable' so they are queued for the next boot.
  # We use || true to ensure the script doesn't crash if a minor package like lm_sensors isn't installed yet
  systemctl enable "${service}" || echo "    WARNING: Failed to enable ${service}. Is it installed?"
done

# Note: getty@.service is heavily tied to the tty login prompt and is enabled by systemd natively, 
# but if you need it explicitly mapped, it is handled dynamically by systemd.

echo "Service activation: OK"
