#!/usr/bin/env bash
# 02-package-check.sh
# Verifies required Arch Linux packages and installs missing ones.

# Strict Error Handling
set -euo pipefail

echo "Starting Package Validation & Installation..."

# Define the required packages based on project specifications
REQUIRED_PACKAGES=(
  base linux-lts linux-lts-headers linux-firmware bind btrfs-progs btop
  caddy cronie dnscrypt-proxy nftables dnsmasq grub inetutils minidlna nano
  net-tools openssh openvpn perl python-cryptography python-flask rclone
  stress-ng sudo tcpdump vnstat which wireguard-tools iproute2 dosfstools
)

MISSING_PACKAGES=()

echo "Checking local package database..."

# Loop through each package and check its install status
for pkg in "${REQUIRED_PACKAGES[@]}"; do
  if ! pacman -Qq "${pkg}" &> /dev/null; then
    MISSING_PACKAGES+=("${pkg}")
  fi
done

# Install missing packages if needed
if [[ ${#MISSING_PACKAGES[@]} -ne 0 ]]; then
  echo "The following required packages are missing:"
  for missing in "${MISSING_PACKAGES[@]}"; do
    echo "  - ${missing}"
  done

  read -r -p "Install missing packages now? [Y/n]: " INSTALL_CHOICE </dev/tty

  if [[ ! "$INSTALL_CHOICE" =~ ^[Nn]$ ]]; then
    echo "Synchronizing databases, updating system, and installing missing packages..."
    # Using -Syu prevents partial upgrades. --noconfirm allows piped execution to succeed.
    pacman -Syu --needed --noconfirm "${MISSING_PACKAGES[@]}"
    echo "Package installation completed."
  else
    echo "Package installation skipped."
    exit 1
  fi
fi

echo "Package validation: OK"
