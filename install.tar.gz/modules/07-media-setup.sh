#!/usr/bin/env bash
# 07-media-setup.sh
# Configures the DLNA media server environment, users, and permissions.

# Strict Error Handling
set -euo pipefail

echo "Starting DLNA Media Environment Setup..."

: "${REAL_USER:?ERROR: REAL_USER is not set}"

# 1. Create the 'media' group
if ! getent group media >/dev/null 2>&1; then
  groupadd media
  echo "  - Created group: media"
else
  echo "  - Group 'media' already exists. Skipping."
fi

# 2. Create the 'share' user and capture password
SHARE_PASS="[HIDDEN - Previously Set]"

if ! id -u share >/dev/null 2>&1; then
  useradd -m -s /bin/bash share
  echo "  - Created user: share"
  
  echo "------------------------------------------------"
  echo "Please set a secure password for the 'share' user:"
  echo "------------------------------------------------"
  
  # Loop until the user types matching passwords
  while true; do
    read -r -s -p "Password: " SHARE_PASS
    echo
    read -r -s -p "Confirm Password: " SHARE_PASS_CONFIRM
    echo
    if [[ "${SHARE_PASS}" == "${SHARE_PASS_CONFIRM}" ]]; then
      break
    else
      echo "ERROR: Passwords do not match. Please try again."
    fi
  done

  # Apply the password securely
  echo "share:${SHARE_PASS}" | chpasswd
else
  echo "  - User 'share' already exists. Skipping creation."
  # If you want to force a password reset on existing users, you could add that logic here.
fi

# 3. Add users to the media group
usermod -aG media "${REAL_USER}"
usermod -aG media share
echo "  - Added '${REAL_USER}' and 'share' to the 'media' group."

# 4. Set up the DLNA directory with SetGID
mkdir -p /srv/dlna
chown -R "${REAL_USER}:media" /srv/dlna
chmod 2775 /srv/dlna
echo "  - Configured /srv/dlna with SetGID permissions (2775)."

# 5. Create a symlink in the share user's home directory
SHARE_HOME=$(getent passwd share | cut -d: -f6)

if [[ ! -e "${SHARE_HOME}/DLNA" ]]; then
  ln -s /srv/dlna "${SHARE_HOME}/DLNA"
  chown -h share:share "${SHARE_HOME}/DLNA"
  echo "  - Created SFTP symlink: ${SHARE_HOME}/DLNA -> /srv/dlna"
else
  echo "  - Symlink ${SHARE_HOME}/DLNA already exists. Skipping."
fi

# 6. Display Connection Information and Pause
echo ""
echo "================================================================"
echo "                   MEDIA SHARE ACCESS INFO                      "
echo "================================================================"
echo "Protocol: sftp"
echo "Server: 172.22.0.1"
echo "User: share"
echo "Password: ${SHARE_PASS}"
echo "Path: /home/share/"
echo "Port: 22"
echo ""
echo "Or for file manager use this link and the username and pass of share:"
echo "sftp://share@172.22.0.1/home/share/"
echo "User: share"
echo "Password: ${SHARE_PASS}"
echo "================================================================"
echo ""

# Pause the script until the user presses a key
read -n 1 -s -r -p "Please save this information, then press any key to continue..."
echo ""
echo "DLNA Media setup: OK"
