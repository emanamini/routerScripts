#!/usr/bin/env bash
# ==============================================================================
# Module: 01-system-check.sh
# Description: Validates system requirements and configures initial system parameters
# ==============================================================================

# Strict Error Handling
set -euo pipefail

echo "Starting System Validation..."

# Check for Root Privileges
if [[ "${EUID}" -ne 0 ]]; then
    echo "ERROR: This installer must be run as root." >&2
    exit 1
fi

echo "Root privileges: OK"

# ==============================================================================
# Timezone Configuration
# ==============================================================================

# Allow non-interactive override if TIMEZONE env variable is pre-set
if [[ -n "${TIMEZONE:-}" ]]; then
    TARGET_TZ="${TIMEZONE}"
    echo "Using environment predefined timezone: ${TARGET_TZ}"
else
    echo "------------------------------------------"
    echo "Select System Timezone:"
    echo "  1) Asia/Tehran (Default)"
    echo "  2) UTC"
    echo "  3) Europe/London"
    echo "  4) America/New_York"
    echo "  5) Custom timezone (enter manually)"
    echo "------------------------------------------"

    # Read safely from controlling terminal
    if [[ -t 0 ]] || [[ -c /dev/tty ]]; then
        read -r -p "Enter choice [1-5, Default: 1]: " TZ_CHOICE </dev/tty || TZ_CHOICE="1"
    else
        TZ_CHOICE="1"
    fi

    TZ_CHOICE="${TZ_CHOICE:-1}"

    case "${TZ_CHOICE}" in
        1) TARGET_TZ="Asia/Tehran" ;;
        2) TARGET_TZ="UTC" ;;
        3) TARGET_TZ="Europe/London" ;;
        4) TARGET_TZ="America/New_York" ;;
        5)
            read -r -p "Enter custom timezone (e.g. Asia/Dubai): " TARGET_TZ </dev/tty
            ;;
        *)
            echo "Invalid option selected, falling back to default (Asia/Tehran)."
            TARGET_TZ="Asia/Tehran"
            ;;
    esac
fi

# Apply timezone (Detects if running on installer host vs inside chroot)
TZ_PATH="/usr/share/zoneinfo/${TARGET_TZ}"

if [[ ! -f "${TZ_PATH}" ]]; then
    echo "ERROR: Timezone '${TARGET_TZ}' not found at ${TZ_PATH}!" >&2
    exit 1
fi

# Determine target directory (/mnt/etc/localtime if staging on host ISO, else /etc/localtime)
if [[ -d "/mnt/etc" ]] && [[ ! -f "/etc/arch-release" ]]; then
    TARGET_LINK="/mnt/etc/localtime"
else
    TARGET_LINK="/etc/localtime"
fi

ln -sf "${TZ_PATH}" "${TARGET_LINK}"
echo "System timezone successfully configured to: ${TARGET_TZ} (${TARGET_LINK})"

echo "System Check Complete: OK"
