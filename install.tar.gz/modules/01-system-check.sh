#!/usr/bin/env bash

# ==============================================================================
# Welcome Notice & Documentation Prompt
# ==============================================================================

GREEN='\033[0;32m'
NC='\033[0m' # No Color

echo -e "${GREEN}"
echo "=================================================================="
echo " Welcome to the Automated Arch Router Installer"
echo "=================================================================="
echo "This script automates a long and complex setup to save you time."
echo ""
echo "IMPORTANT: To understand how your router works and maintain it"
echo "later, you MUST read the documentation first:"
echo ""
echo "  https://github.com/emanamini/routerScripts"
echo ""
echo "It is strongly recommended to read this guide, especially to learn"
echo "how the Arch Portal works. Without it, router maintenance will"
echo "be difficult."
echo "=================================================================="
echo -e "${NC}"

# Pause until user presses Enter
if [[ -t 0 ]] || [[ -c /dev/tty ]]; then
    read -r -p "Press [Enter] to accept and continue..." </dev/tty || true
else
    read -r -p "Press [Enter] to accept and continue..." || true
fi
echo ""

# ==============================================================================
# Module: 01-system-check.sh
# Description: Validates system requirements and configures initial system parameters
# ==============================================================================

# Strict Error Handling
set -euo pipefail

echo "Starting System Validation..."

# Check for Root Privileges
if [[ "${EUID}" -ne 0 ]]; then
    echo "ERROR: This installer must be run as root." >&2
    exit 1
fi

echo "Root privileges: OK"

# ==============================================================================
# Timezone Configuration
# ==============================================================================

# Allow non-interactive override if TIMEZONE env variable is pre-set
if [[ -n "${TIMEZONE:-}" ]]; then
    TARGET_TZ="${TIMEZONE}"
    echo "Using environment predefined timezone: ${TARGET_TZ}"
else
    echo "------------------------------------------"
    echo "Select System Timezone:"
    echo "  1) Asia/Tehran (Default)"
    echo "  2) UTC"
    echo "  3) Europe/London"
    echo "  4) America/New_York"
    echo "  5) Custom timezone (enter manually)"
    echo "------------------------------------------"

    # Read safely from controlling terminal
    if [[ -t 0 ]] || [[ -c /dev/tty ]]; then
        read -r -p "Enter choice [1-5, Default: 1]: " TZ_CHOICE </dev/tty || TZ_CHOICE="1"
    else
        TZ_CHOICE="1"
    fi

    TZ_CHOICE="${TZ_CHOICE:-1}"

    case "${TZ_CHOICE}" in
        1) TARGET_TZ="Asia/Tehran" ;;
        2) TARGET_TZ="UTC" ;;
        3) TARGET_TZ="Europe/London" ;;
        4) TARGET_TZ="America/New_York" ;;
        5)
            read -r -p "Enter custom timezone (e.g. Asia/Dubai): " TARGET_TZ </dev/tty
            ;;
        *)
            echo "Invalid option selected, falling back to default (Asia/Tehran)."
            TARGET_TZ="Asia/Tehran"
            ;;
    esac
fi

# Apply timezone (Detects if running on installer host vs inside chroot)
TZ_PATH="/usr/share/zoneinfo/${TARGET_TZ}"

if [[ ! -f "${TZ_PATH}" ]]; then
    echo "ERROR: Timezone '${TARGET_TZ}' not found at ${TZ_PATH}!" >&2
    exit 1
fi

# Determine target directory (/mnt/etc/localtime if staging on host ISO, else /etc/localtime)
if [[ -d "/mnt/etc" ]] && [[ ! -f "/etc/arch-release" ]]; then
    TARGET_LINK="/mnt/etc/localtime"
else
    TARGET_LINK="/etc/localtime"
fi

ln -sf "${TZ_PATH}" "${TARGET_LINK}"
echo "System timezone successfully configured to: ${TARGET_TZ} (${TARGET_LINK})"

# ==============================================================================
# User Resolution Function
# ==============================================================================

detect_invoking_user() {
    # Resolve the user who invoked sudo
    REAL_USER="${SUDO_USER:-}"

    if [[ -z "${REAL_USER}" ]] || [[ "${REAL_USER}" == "root" ]]; then
        echo "ERROR: This installer must be invoked via 'sudo' from a standard non-root user account." >&2
        echo "ERROR: Do not run this script directly as root." >&2
        exit 1
    fi

    # Query system user database for the user's home directory
    REAL_HOME="$(getent passwd "${REAL_USER}" | cut -d: -f6 2>/dev/null || echo "/home/${REAL_USER}")"

    export REAL_USER
    export REAL_HOME

    echo "Invoking User Context: ${REAL_USER} (${REAL_HOME})"
}

# Execute User Detection
detect_invoking_user

echo "System Check Complete: OK"
