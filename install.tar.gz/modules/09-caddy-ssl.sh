#!/usr/bin/env bash
set -e

# Colors for interactive output
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "\n${CYAN}===========================================${NC}"
echo -e "${CYAN}   Optional Module: Cloudflare & Caddy SSL ${NC}"
echo -e "${CYAN}===========================================${NC}\n"

read -p "Do you want to configure Caddy with Cloudflare DNS-01 SSL? [y/N]: " ENABLE_SSL
if [[ ! "$ENABLE_SSL" =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}Skipping Caddy SSL setup.${NC}"
    exit 0
fi

echo -e "\n${YELLOW}--- Cloudflare API Token Instructions ---${NC}"
echo -e "Please create a custom API Token in your Cloudflare account."
echo -e "You must grant it these ${GREEN}THREE${NC} specific permissions for your zone:"
echo -e "  1. ${GREEN}Zone Read${NC}"
echo -e "  2. ${GREEN}DNS Read${NC}"
echo -e "  3. ${GREEN}DNS Write${NC}"
echo -e "Need help? Check out the tutorial here: ${CYAN}https://github.com/YOUR_USERNAME/YOUR_REPO/wiki/Cloudflare-SSL-Tutorial${NC}\n"

# Prompt for Domain
read -rp "Enter your Domain Name (e.g., ilola.ir): " DOMAIN_NAME
while [[ -z "$DOMAIN_NAME" ]]; do
    echo -e "${YELLOW}Domain name cannot be empty.${NC}"
    read -rp "Enter your Domain Name: " DOMAIN_NAME
done

# Prompt for API Token
read -rp "Enter your Cloudflare API Token (cfat_...): " CF_API_TOKEN
echo ""
while [[ -z "$CF_API_TOKEN" ]]; do
    echo -e "${YELLOW}API Token cannot be empty.${NC}"
    read -sp "Enter your Cloudflare API Token: " CF_API_TOKEN
    echo ""
done

echo -e "\n${GREEN}[1/5] Downloading & Installing Custom Caddy Binary...${NC}"
ARCH=$(uname -m)
case "$ARCH" in
    x86_64) CADDY_ARCH="amd64" ;;
    aarch64) CADDY_ARCH="arm64" ;;
    *) echo "Unsupported architecture: $ARCH"; exit 1 ;;
esac

curl -sL "https://caddyserver.com/api/download?os=linux&arch=${CADDY_ARCH}&p=github.com/caddy-dns/cloudflare" -o /tmp/caddy
mv /tmp/caddy /usr/local/bin/caddy
chmod +x /usr/local/bin/caddy

echo -e "${GREEN}[2/5] Applying Systemd Service Override...${NC}"
mkdir -p /etc/systemd/system/caddy.service.d
cat <<EOF > /etc/systemd/system/caddy.service.d/override.conf
[Unit]
After=network-online.target arch-portal.service
Wants=network-online.target arch-portal.service
StartLimitIntervalSec=60s
StartLimitBurst=10

[Service]
# Clear and override the Validation pre-check
ExecStartPre=
ExecStartPre=/usr/local/bin/caddy validate --config /etc/caddy/Caddyfile

# Clear and override the Main startup command
ExecStart=
ExecStart=/usr/local/bin/caddy run --environ --config /etc/caddy/Caddyfile
Restart=on-failure
RestartSec=5s
EOF

echo -e "${GREEN}[3/5] Generating Caddyfile...${NC}"
mkdir -p /etc/caddy
cat <<EOF > /etc/caddy/Caddyfile
{
    admin "unix//run/caddy/admin.socket"
}

${DOMAIN_NAME}, www.${DOMAIN_NAME} {
    tls {
        dns cloudflare ${CF_API_TOKEN}
    }
    reverse_proxy 127.0.0.1:8080
}

http://172.22.0.1 {
    reverse_proxy 127.0.0.1:8080
}

https://172.22.0.1 {
    tls internal
    reverse_proxy 127.0.0.1:8080
}
EOF

echo -e "${GREEN}[4/5] Updating Local DNS (dnsmasq)...${NC}"
# Prevent duplicate entries if the script is run multiple times
if ! grep -q "address=/${DOMAIN_NAME}/172.22.0.1" /etc/dnsmasq.conf; then
    echo "address=/${DOMAIN_NAME}/172.22.0.1" >> /etc/dnsmasq.conf
fi

echo -e "${GREEN}[5/5] Staging Systemd Environment...${NC}"

# Reload systemd manager configuration so it recognizes new unit files/overrides
systemctl daemon-reload

# Attempt non-disruptive configuration reload only if the service is active and 'lan' is present
if ip link show lan &>/dev/null; then
    echo "LAN interface detected. Attempting live reload of dnsmasq..."
    systemctl try-reload-or-restart dnsmasq.service 2>/dev/null || echo "Notice: Live reload skipped. delayed-startup.service will manage start on boot."
else
    echo "Notice: LAN interface not active. Staging complete."
fi

echo -e "${GREEN}Caddy and DNS staging complete. Startup deferred to delayed-startup.service.${NC}"

echo -e "\n${GREEN}✔ Caddy SSL and Local DNS setup complete for ${DOMAIN_NAME}!${NC}"
