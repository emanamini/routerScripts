#!/usr/bin/env bash
# 06-install-files.sh
# Extracts a tarball of preconfigured files, copies them to destinations, and sets permissions.

# Strict Error Handling
set -euo pipefail

echo "Starting File Installation..."

TAR_FILE="files.tar.gz"

if [[ ! -f "${TAR_FILE}" ]]; then
  echo "ERROR: The archive '${TAR_FILE}' was not found in the installer root." >&2
  exit 1
fi

# 1. Setup Temporary Workspace & Guaranteed Cleanup
TMP_DIR=$(mktemp -d /tmp/router-installer.XXXXXX)

cleanup() {
  echo "Cleaning up temporary workspace (${TMP_DIR})..."
  rm -rf "${TMP_DIR}"
}
trap cleanup EXIT

echo "Extracting ${TAR_FILE} to temporary workspace..."
tar -xzf "${TAR_FILE}" -C "${TMP_DIR}"

# Function: Safely copy files, replace user templates, create missing directories, and set permissions
install_file() {
  local src="${TMP_DIR}/$1"
  local dest="$2"
  local perms="${3:-644}"

  if [[ -f "${src}" ]]; then
    mkdir -p "$(dirname "${dest}")"

    # Perform token substitution for dynamic users (e.g., {{REAL_USER}} -> net/john/etc.)
    # falling back to 'net' if REAL_USER isn't set yet.
    local target_user="${REAL_USER:-net}"
    sed "s/{{REAL_USER}}/${target_user}/g" "${src}" > "${dest}"

    chmod "${perms}" "${dest}"
    chown root:root "${dest}"
    echo "  - Installed: ${dest}"
  else
    echo "  - ERROR: Missing required file in archive: $1" >&2
    exit 1
  fi
}

# 2. Core Networking & System Files
echo "Copying core networking files..."
install_file "nftables.conf" "/etc/nftables.conf"
install_file "dnsmasq.conf" "/etc/dnsmasq.conf"
install_file "rt_tables" "/etc/iproute2/rt_tables"
install_file "resolv.conf" "/etc/resolv.conf"
install_file "vpn-manager.conf" "/etc/vpn-manager.conf"
install_file "dnscrypt-proxy.toml" "/etc/dnscrypt-proxy/dnscrypt-proxy.toml"
install_file "minidlna.conf" "/etc/minidlna.conf"
install_file "Caddyfile" "/etc/caddy/Caddyfile"
# install_file "root-cron" "/var/spool/cron/root" "600"

# echo "Copying systemd-networkd configurations..."
# install_file "wan.network" "/etc/systemd/network/wan.network"
# install_file "lan.network" "/etc/systemd/network/lan.network"

echo "Copying sysctl and udev rules..."
install_file "router.conf" "/etc/sysctl.d/router.conf"
install_file "99-disk-writes.conf" "/etc/sysctl.d/99-disk-writes.conf"
install_file "udev-99-router-diag.rules" "/etc/udev/rules.d/99-router-diag.rules"

echo "Copying systemd services..."
install_file "arch-portal.service" "/etc/systemd/system/arch-portal.service"
install_file "router-diag@.service" "/etc/systemd/system/router-diag@.service"
install_file "vpn-manager.service" "/etc/systemd/system/vpn-manager.service"
install_file "tc.service" "/etc/systemd/system/tc.service"
install_file "delayed-startup.service" "/etc/systemd/system/delayed-startup.service"
install_file "ip-rules.service" "/etc/systemd/system/ip-rules.service"
install_file "wan-watcher.service" "/etc/systemd/system/wan-watcher.service"

echo "Copying systemd override files..."
# install_file "caddyoverride.conf" "/etc/systemd/system/caddy.service.d/override.conf"
install_file "dnsmasqoverride.conf" "/etc/systemd/system/dnsmasq.service.d/override.conf"

# 3. Arch-Portal Files
echo "Copying arch-portal application files..."
install_file "app.py" "/opt/arch-portal/app.py"
install_file "devices.log" "/opt/arch-portal/devices.log"
install_file "icon.png" "/opt/arch-portal/static/icon.png"
install_file "manifest.json" "/opt/arch-portal/static/manifest.json"
install_file "index.html" "/opt/arch-portal/templates/index.html"

# 4. Router Scripts
echo "Copying router scripts to /opt/router/Scripts/..."
ROUTER_SCRIPTS=(
  "bargh" "domain-harvest.sh" "ip-rule.sh" "irdomains.txt" "iriplist.txt"
  "irtr.sh" "rcloneBackup.sh" "router-diag-wrapper.sh" "router-diagnostics.sh"
  "srv.sh" "startup.sh" "tc.sh" "toggle-route" "vns.sh" "vpn-manager.sh" "wan-watcher.sh"
)

for script in "${ROUTER_SCRIPTS[@]}"; do
  install_file "${script}" "/opt/router/Scripts/${script}" "755"
done

chown -R "${REAL_USER}:${REAL_USER}" "/opt/router/Scripts"
echo "  - Changed ownership of /opt/router/Scripts/ to ${REAL_USER}:${REAL_USER}"

# 5. Sudoers Configuration
echo "Configuring sudoers bypass for router scripts and network binaries..."
cat <<EOF > "${TMP_DIR}/99-router-scripts"
${REAL_USER} ALL=(ALL) NOPASSWD: /opt/router/Scripts/toggle-route, /opt/router/Scripts/srv.sh, /usr/local/bin/srv, /usr/bin/reboot, /usr/bin/systemctl, /usr/bin/ip, /usr/bin/wg-quick, /usr/bin/openvpn
EOF

install_file "99-router-scripts" "/etc/sudoers.d/99-router-scripts" "440"

# 6. Symlinks
echo "Creating requested symlinks..."
mkdir -p /usr/local/bin

ln -sf /opt/router/Scripts/srv.sh /usr/local/bin/srv
ln -sf /opt/router/Scripts/bargh /usr/local/bin/bargh
ln -sf /opt/router/Scripts/vns.sh /usr/local/bin/vns

echo "  - Created system binary symlinks in /usr/local/bin/"

: "${REAL_HOME:?ERROR: REAL_HOME is not set}"

ln -sf /opt/router/Scripts "${REAL_HOME}/Scripts"
chown -h "${REAL_USER}:${REAL_USER}" "${REAL_HOME}/Scripts"
echo "  - Created home directory symlink: ${REAL_HOME}/Scripts"

echo "File installation: OK"
