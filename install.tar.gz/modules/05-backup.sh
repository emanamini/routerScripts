#!/usr/bin/env bash
# 05-backup.sh
# Creates timestamped backups of critical configuration files before modification.

# Strict Error Handling
set -euo pipefail

echo "Starting System Backup..."

# Generate a timestamp (YearMonthDay_HourMinuteSecond)
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="/root/router-backup_${TIMESTAMP}"

# Create the backup directory safely
mkdir -p "${BACKUP_DIR}"
echo "Created backup directory at: ${BACKUP_DIR}"

# Define an array of files we plan to overwrite or modify
# We include files mentioned in the spec, plus standard network configs
FILES_TO_BACKUP=(
   "/etc/nftables.conf"
   "/etc/dnsmasq.conf"
   "/etc/resolv.conf"
   "/etc/iproute2/rt_tables"
   "/etc/caddy/Caddyfile"
)

echo "Backing up target configurations..."

# Loop through each target file
for config_file in "${FILES_TO_BACKUP[@]}"; do
  # The -f flag checks if the file exists and is a regular file
  if [[ -f "${config_file}" ]]; then
    # Copy the file to our backup directory
    cp "${config_file}" "${BACKUP_DIR}/"
    echo "  - Backed up: ${config_file}"
  else
    echo "  - Skipped (does not exist): ${config_file}"
  fi
done

echo "System backup: OK"
