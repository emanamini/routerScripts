#!/usr/bin/env bash
# 03-user-detection.sh
# Identifies the target non-root user and their home directory.

# Strict Error Handling
set -euo pipefail

echo "Starting User Detection..."

# Check if the script was run via sudo by looking for SUDO_USER
if [[ -n "${SUDO_USER:-}" ]]; then
  REAL_USER="${SUDO_USER}"
else
  # If SUDO_USER is empty, they logged in directly as root, which we want to avoid for file ownership reasons.
  echo "ERROR: Could not detect the real user." >&2
  echo "Please run this installer using 'sudo' from your standard user account, rather than logging in directly as root." >&2
  exit 1
fi

# Securely extract the real user's home directory from the system's password file
REAL_HOME=$(getent passwd "${REAL_USER}" | cut -d: -f6)

# Verify the home directory actually exists
if [[ ! -d "${REAL_HOME}" ]]; then
  echo "ERROR: Home directory for ${REAL_USER} (${REAL_HOME}) does not exist." >&2
  exit 1
fi

echo "Detected real user: ${REAL_USER}"
echo "Detected home directory: ${REAL_HOME}"
echo "User detection: OK"
